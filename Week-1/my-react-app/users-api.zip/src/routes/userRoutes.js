
import express from "express";

import {
  getUsers,
  getUser,
  addUser,
  updateUser,
  removeUser,
} from "../controllers/userController.js";

const router = express.Router();

router.get("/", getUsers);
router.get("/:id", getUser);
router.post("/", addUser);
router.put("/:id", updateUser);
router.delete("/:id", removeUser);

export default router;

